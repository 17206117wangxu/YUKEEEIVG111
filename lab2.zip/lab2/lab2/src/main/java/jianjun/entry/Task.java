package jianjun.entry;

public class Task {
	private int id;
	private String content;
	private String information;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getInformation(){
		return information;
	}
	public void setInformation(String information){
		this.information = information;
	}
	
	public Task(int id,String content,String information) {
		this.id=id;
		this.content=content;
		this.information = information;
	}
}
