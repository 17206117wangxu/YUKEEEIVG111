package wangxu.rest;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import jianjun.entry.Task;

@RestController
public class TaskRestController {
	String[] task1= {"王旭的资料","谢可寅的资料","戴燕妮的资料","金子涵的资料","刘令姿的资料"};
	String[] task2= {"身高188 体重65 因实在太帅被称为史上最帅小伙","身高165 体重42 王旭的一号夫人","身高168 体重43 王旭的二号夫人","身高170 体重45 王旭的三号夫人","身高172 体重46 王旭的三号夫人"};
@GetMapping("/task/{id}")
	
    public Task task(@PathVariable (value="id") int id) {
        return new Task(id,task1[id],task2[id]);
    }
}
