
$(document).ready(function() {
	
	
	$('#btn').click(function(){
		var id=$("#text1").val();
		
		
		$.ajax({
	        url: "http://localhost:8080/task/"+ id
	    }).then(function(data) {
	    	$("#title").text(data.content);
	    	$("#div").text(data.information);
	    	
	    });
	});    
});
