package jianjun;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import jianjun.entry.Task;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc

public class TaskRestControllerTest {
	@Autowired
	private MockMvc mockMvc;	//mockito,spring-test
	@Test
	public void test() throws Exception {
		MvcResult result = mockMvc
.perform(MockMvcRequestBuilders.get("http://localhost:8080/task/1"))
        .andReturn();		
	
ObjectMapper mapper = new ObjectMapper(); //jackson
String jsonstr = result.getResponse().getContentAsString();
		Task task = mapper.readValue(jsonstr, Task.class);
		assertNotNull(task); 
		System.out.println(task.getContent());
		assertTrue(task.getContent().contains("bs")); 
	}

}
