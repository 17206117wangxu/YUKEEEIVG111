package webadv.s99201105.p02;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
import org.apache.commons.codec.digest.DigestUtils;
public class App {
	private static final String USERNAME = "Wangxu";//此处定义用户名
	private static final String PASSWORD = "123456";//定义密码

    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
        if (args.length < 1) {
        	System.err.println("Please provide an input!");
            System.exit(0);
        }
        if (args[0].equals("123456")) {
            System.out.println("用户名:");
            String username = sc.next();
            System.out.println("密码:");
            String password = sc.next();
            if(username.equals(USERNAME) && password.equals(PASSWORD)){
            	System.out.println("登录成功!");
            	System.out.println("用户名:"+USERNAME);
            	System.out.println("密码:"+sha256hex(args[0]));
            	}else{
            	System.out.println("用户名或密码错误");
            	}
        }
        }
    
    public static String sha256hex(String input) {
        return DigestUtils.sha256Hex(input);
    }
}
