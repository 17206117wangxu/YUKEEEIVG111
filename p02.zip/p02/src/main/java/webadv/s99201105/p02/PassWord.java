package webadv.s99201105.p02;

public class PassWord {

}
